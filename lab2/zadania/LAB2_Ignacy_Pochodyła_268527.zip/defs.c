//#include "defs.h"

//definicje uprzednio zadeklarowanej funkji i zmiennych

float a = 15.096745;
float b = 45.75757575;

float add(float a, float b){
    return a + b;
}

