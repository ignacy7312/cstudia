#pragma once //załączenie danego headera tylko raz w obrębie jednostki translacji

//deklaracja funkcji i dwóch zmienynch

float a;
float b;

float add(float a, float b);
