#include <stdio.h>
#include "defs.h"


int main(){
	

    float result = add(a, b);
    printf("Wynik dodawania: %f", result);
	

    return 0;
}